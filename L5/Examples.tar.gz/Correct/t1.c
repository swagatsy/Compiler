void main(){ 
	int *ptr;
	*ptr = 5;
}