./Parser $1
f=$1'.s'
./read_sym $1 > $f
